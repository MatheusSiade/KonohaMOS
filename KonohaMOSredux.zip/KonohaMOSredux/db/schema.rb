# This file is auto-generated from the current state of the database. Instead
# of editing this file, please use the migrations feature of Active Record to
# incrementally modify your database, and then regenerate this schema definition.
#
# Note that this schema.rb definition is the authoritative source for your
# database schema. If you need to create the application database on another
# system, you should be using db:schema:load, not running all the migrations
# from scratch. The latter is a flawed and unsustainable approach (the more migrations
# you'll amass, the slower it'll run and the greater likelihood for issues).
#
# It's strongly recommended that you check this file into your version control system.

ActiveRecord::Schema.define(version: 20171227192659) do

  create_table "missions", force: :cascade do |t|
    t.string "title"
    t.string "local"
    t.string "challenge_label"
    t.integer "team_id"
    t.string "creator"
    t.string "comments"
    t.string "price"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["team_id"], name: "index_missions_on_team_id"
  end

  create_table "people", force: :cascade do |t|
    t.string "name"
    t.integer "person_id"
    t.string "birth_date"
    t.string "home_address"
    t.string "username"
    t.string "user_type"
    t.string "rank_ninja"
    t.float "average"
    t.string "email"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "teams", force: :cascade do |t|
    t.string "name"
    t.integer "ninja1_id"
    t.integer "ninja2_id"
    t.integer "ninja3_id"
    t.integer "ninjasuperior_id"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["ninja1_id"], name: "index_teams_on_ninja1_id"
    t.index ["ninja2_id"], name: "index_teams_on_ninja2_id"
    t.index ["ninja3_id"], name: "index_teams_on_ninja3_id"
    t.index ["ninjasuperior_id"], name: "index_teams_on_ninjasuperior_id"
  end

end
