class CreateTeams < ActiveRecord::Migration[5.1]
  def change
    create_table :teams do |t|
      t.string :name
      t.references :ninja1
      t.references :ninja2
      t.references :ninja3
      t.references :ninjasuperior

      t.timestamps
    end
  end
end
