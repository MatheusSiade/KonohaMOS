class CreateMissions < ActiveRecord::Migration[5.1]
  def change
    create_table :missions do |t|
      t.string :title
      t.string :local
      t.string :challenge_label
      t.references :team
      t.string :creator
      t.string :comments
      t.string :price

      t.timestamps
    end
  end
end
