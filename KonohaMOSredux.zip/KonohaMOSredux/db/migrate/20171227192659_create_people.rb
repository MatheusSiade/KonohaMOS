class CreatePeople < ActiveRecord::Migration[5.1]
  def change
    create_table :people do |t|
      t.string :name
      t.integer :person_id
      t.string :birth_date
      t.string :home_address
      t.string :username
      t.string :user_type
      t.string :rank_ninja
      t.float :average
      t.string :email

      t.timestamps
    end
  end
end
