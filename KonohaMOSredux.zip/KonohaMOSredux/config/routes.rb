Rails.application.routes.draw do
  get 'welcome/index'

  resources :teams
  resources :people
  resources :missions

  root 'welcome#index'
end
