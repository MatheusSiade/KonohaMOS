class Person < ApplicationRecord


end
