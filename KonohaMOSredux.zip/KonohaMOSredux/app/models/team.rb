class Team < ApplicationRecord

end
