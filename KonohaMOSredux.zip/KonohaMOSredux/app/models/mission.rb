class Mission < ApplicationRecord
  has_one :team
end
