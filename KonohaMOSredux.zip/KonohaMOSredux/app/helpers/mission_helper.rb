module MissionHelper
end
