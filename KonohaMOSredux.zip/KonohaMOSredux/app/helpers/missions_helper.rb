module MissionsHelper
end
